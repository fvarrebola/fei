1;

clear;
clf;

# *****************************************************************************
# Gr�ficos das fun��es 1, 2, 3 e 4
# *****************************************************************************
fpath_1 = input("Digite o nome completo para o arquivo (funcao 1): ", "s");
pontos_1 = dlmread(fpath_1, ",");
y_1 = pontos_1(:,3);

fpath_2 = input("Digite o nome completo para o arquivo (funcao 2): ", "s");
pontos_2 = dlmread(fpath_2, ",");
y_2 = pontos_2(:,3);

fpath_3 = input("Digite o nome completo para o arquivo (funcao 3): ", "s");
pontos_3 = dlmread(fpath_3, ",");
y_3 = pontos_3(:,3);

fpath_4 = input("Digite o nome completo para o arquivo (funcao 4): ", "s");
pontos_4 = dlmread(fpath_4, ",");
y_4 = pontos_4(:,4);

figure(1, "Position", get(0,"screensize"));

bar([y_1, y_2, y_3, y_4]);
grid on;
axis("tight");
title("Quantidade de amostras versus taxa de erro");
xlabel("Quantidade de amostras");
ylabel("Taxa de erro");
legend('(1)', '(2)', '(3)', '(4)');
legend boxon;
set(gca,'xtick', [0,1,2,3,4,5,6,7,8]);
set(gca,'xticklabel', {'0', '10^1', '10^2', '10^3', '10^4', '10^5', '10^6', '10^7', '10^8'});

# pergunta ao usuario se o grafico deve ser salvo
save = yes_or_no("Deseja salvar o JPG? ");
if save
  print (strcat("taxa_erro___monte-carlo", ".jpg"));
endif
close();
# *****************************************************************************