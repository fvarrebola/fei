1;

clear;
clf;

fpath = input("Digite o nome completo para o arquivo: ", "s");
lambda = input("Informe o lambda: ", "s");

pontos = dlmread(fpath, ",");
x_p = pontos(:,1);
y_p = pontos(:,2);
z_p = pontos(:,3);

figure(1, "Position", get(0,"screensize"));

hold on;
plot3(x_p, y_p, z_p, "-r");
hold off;
grid on;
grid minor on;
title(strcat("Descida de gradiente f(x) = (1 - y)^2 + 100*(y - x^2)^2 com x_{0} = (2, 2) e \\lambda = ", lambda));
xlabel("x");
ylabel("y");
zlabel("f(x, y)");

# pergunta ao usuario se o grafico deve ser salvo
save = yes_or_no("Deseja salvar o JPG? ");
if save
  print (strcat(fpath, ".jpg"));
endif
close();