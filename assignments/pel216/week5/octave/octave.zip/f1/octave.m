1;

clear;
clf;

fpath = input("Digite o nome completo para o arquivo: ", "s");
lambda = input("Informe o lambda: ", "s");

pontos = dlmread(fpath, ",");
x_p = pontos(:,1);
y_p = pontos(:,2);
x = [-2:.05:2];
y = x.^2;

figure(1, "Position", get(0,"screensize"));

plot(x, y, "-b");
hold on;
plot(x_p, y_p, "-xr");
hold off;
grid on;
grid minor on;
axis("tight");
title(strcat("Descida de gradiente f(x) = x^2 com x_{0} = 2 e \\lambda = ", lambda));
xlabel("x");
ylabel("f(x)");
legend("f(x) = x^2", "Descida de gradiente");
legend location north;
legend boxon;

# pergunta ao usuario se o grafico deve ser salvo
save = yes_or_no("Deseja salvar o JPG? ");
if save
  print (strcat(fpath, ".jpg"));
endif
close();